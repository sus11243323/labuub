﻿<#
ULTIMATE FAKE HACKING TOOLKIT v15.0
█▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█
█                                                                                              █
█  ██╗  ██╗ █████╗  ██████╗██╗  ██╗ ██╗███╗   ██╗ ██████╗ ███████╗██████╗ ███████╗██████╗     █
█  ██║  ██║██╔══██╗██╔════╝██║ ██╔╝ ██║████╗  ██║██╔════╝ ██╔════╝██╔══██╗██╔════╝██╔══██╗    █
█  ██████╔╝███████║██║     █████╔╝  ██║██╔██╗ ██║██║  ███╗█████╗  ██████╔╝█████╗  ██║  ██║    █
█  ██╔══██╗██╔══██║██║     ██╔═██╗  ██║██║╚██╗██║██║   ██║██╔══╝  ██╔══██╗██╔══╝  ██║  ██║    █
█  ██║  ██║██║  ██║╚██████╗██║  ██╗ ██║██║ ╚████║╚██████╔╝███████╗██║  ██║███████╗██████╔╝    █
█  ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝ ╚═╝╚═╝  ╚═══╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝╚══════╝╚═════╝     █
█                                                                                              █
█▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█
#><#
ULTIMATE FAKE HACKING TOOLKIT v15.0
#>

# Enhanced visual effects with sleep duration fix
function Show-HackingEffect {
    param (
        [int]$Duration,
        [string]$Target,
        [string]$AttackType
    )
    
    $startTime = Get-Date
    $endTime = $startTime.AddSeconds($Duration)
    $colors = @("Red","DarkRed","Green","DarkGreen","Yellow","DarkYellow","Blue","DarkBlue","Magenta","DarkMagenta")
    $verbs = @("Bruteforcing","Cracking","Injecting","Exploiting","Bypassing","Decrypting","Hijacking","Overriding","Penetrating","Compromising")
    $nouns = @("firewall","credentials","encryption","services","kernel","BIOS","protocol","handshake","database","certificates","VPN","antivirus")
    $codes = @("0xFA7E", "0xC0DE", "0xDEC0", "0xBEEF", "0xCAFE", "0xDEAD", "0xF00D", "0x1337")
    
    # Display ASCII art based on attack category
    $category = $AttackType.Split(':')[0].Trim()
    Show-CategoryArt $category
    
    Write-Host "`n[!] INITIATING $AttackType ATTACK ON $Target [!]" -ForegroundColor Red
    Write-Host "[*] Estimated completion: $Duration seconds" -ForegroundColor Yellow
    
    while ((Get-Date) -lt $endTime) {
        $progress = [int](((Get-Date) - $startTime).TotalSeconds / $Duration * 100)
        if ($progress -gt 100) { $progress = 100 }
        
        $timeLeft = [math]::Round(($endTime - (Get-Date)).TotalSeconds)
        $randomText = "$($verbs | Get-Random) $($nouns | Get-Random)..." + 
                     " [CODE:$($codes | Get-Random)] " + 
                     "TIME LEFT: ${timeLeft}s " +
                     "$(if ((Get-Random -Maximum 100) -gt 50) { "SUCCESS" } else { "FAILED-RETRYING" })"
        
        Write-Progress -Activity "ATTACK IN PROGRESS" -Status $randomText -PercentComplete $progress
        Write-Host "[$(Get-Date -Format 'HH:mm:ss')] $randomText" -ForegroundColor ($colors | Get-Random)
        
        # Calculate sleep time correctly to prevent negative values
        $timeLeftMs = ($endTime - (Get-Date)).TotalMilliseconds
        if ($timeLeftMs -le 0) { break }
        
        $delay = [math]::Min($timeLeftMs, (Get-Random -Minimum 100 -Maximum 2000))
        Start-Sleep -Milliseconds $delay
    }
    
    Write-Progress -Activity "ATTACK COMPLETE" -Completed
    Write-Host "[+] TARGET COMPROMISED! [+]" -ForegroundColor Green
    
    # Play completion sound
    if ($enableSounds) {
        1..3 | ForEach-Object {
            [console]::beep(1500, 300)
            Start-Sleep -Milliseconds 100
        }
    }
    
    Start-Sleep -Seconds 1
}

# ASCII Art for Categories
function Show-CategoryArt {
    param($category)
    
    $art = @{
        "Network" = @"
                
           
                   
                
               
                    
"@
        
        "System" = @"
          
      
              
                
                  
                     
"@
        
        "Web" = @"
         
        
        
      
    
       
"@
        
        "Credentials" = @"
                 
           
                           
                          
               
                  
"@
        
        "Wireless" = @"
              
             
               
             
      
        
"@
        
        "Malware" = @"
                    
             
              
            
              
                   
"@
        
        "Cloud" = @"
                
            
                      
                      
    
          
"@
        
        "Social" = @"
              
         
                 
                 
      
         
"@
        
        "Crypto" = @"
          
     
                 
                     
                          
                           
"@
        
        "Forensics" = @"
           
      
                 
                
            
                
"@
    }
    
    if ($art.ContainsKey($category)) {
        Write-Host $art[$category] -ForegroundColor (Get-Random @("Cyan","Green","Yellow"))
    }
    else {
        Write-Host "`n[ $category ATTACK ]" -ForegroundColor Magenta
    }
}

# Generate realistic hacking results
function Get-FakeHackingResults {
    param (
        [string]$ServiceName,
        [string]$Target,
        [int]$Duration
    )
    
    $ip = "$(Get-Random -Minimum 1 -Maximum 255).$(Get-Random -Minimum 0 -Maximum 255).$(Get-Random -Minimum 0 -Maximum 255).$(Get-Random -Minimum 1 -Maximum 255)"
    $mac = (1..6 | ForEach-Object { "{0:X2}" -f (Get-Random -Minimum 0 -Maximum 255) }) -join ':'
    
    $result = @"
=== ULTIMATE HACKING TOOLKIT v15.0 ===
SERVICE: $ServiceName
TARGET: $Target
DURATION: $Duration seconds
DATE: $(Get-Date -Format "yyyy-MM-dd HH:mm:ss")
STATUS: COMPROMISED

[SYSTEM INFORMATION]
IP: $ip
MAC: $mac
OS: $(@("Windows 11 Pro","Ubuntu 22.04","macOS 14.0","CentOS 9","Kali Linux 2023") | Get-Random)
UPTIME: $(Get-Random -Minimum 1 -Maximum 30) days
DOMAIN: $(@("CORP","SECURE","GLOBAL","INTERNAL") | Get-Random).$(@("COM","NET","ORG","INT") | Get-Random)

[COMPROMISE DETAILS]
Exploited Vulnerability: $(@("Zero-Day","EternalBlue","Shellshock","Heartbleed","Log4Shell","BlueKeep","DirtyPipe") | Get-Random)
Access Level: $(@("Root","Admin","System","Domain Admin","Enterprise Admin") | Get-Random)
Persistence: $(@("Registry Key","Scheduled Task","Kernel Module","Bootkit") | Get-Random)
Data Exfiltrated: $(Get-Random -Minimum 10 -Maximum 5000) MB
Backdoor: $(@("Reverse Shell","Web Shell","RAT","C2 Connection") | Get-Random)

[CREDENTIALS COMPROMISED]
Username: $(@("admin","root","administrator","service","sqladmin") | Get-Random)
Password: $(@("P@ssw0rd!","123456789","Winter2023!","SecurePass1","Admin@123") | Get-Random)
Hash: $(Get-Random -Minimum 1000000000 -Maximum 9999999999)

[SENSITIVE DATA FOUND]
$(if ((Get-Random -Maximum 100) -gt 30) { "Credit Cards: " + (1..(Get-Random -Minimum 1 -Maximum 5) | ForEach-Object { "****-****-****-" + (Get-Random -Minimum 1000 -Maximum 9999) }) -join ", " } else { "No financial data found" })
$(if ((Get-Random -Maximum 100) -gt 50) { "SSNs: " + (1..(Get-Random -Minimum 1 -Maximum 3) | ForEach-Object { "***-**-" + (Get-Random -Minimum 1000 -Maximum 9999) }) -join ", " } else { "No PII data found" })

[NEXT STEPS]
1. Maintain access: $(@("Create new admin account","Install persistent backdoor","Modify firewall rules") | Get-Random)
2. Cover tracks: $(@("Clear logs","Modify timestamps","Encrypt activity") | Get-Random)
3. Exfiltrate data: $(@("DNS tunneling","HTTPS covert channel","FTP transfer") | Get-Random)
4. Pivot to: $(Get-Random -Minimum 1 -Maximum 255).$(Get-Random -Minimum 0 -Maximum 255).$(Get-Random -Minimum 0 -Maximum 255).0/24

[WARNING]
This is a simulated attack for educational purposes only!
Unauthorized hacking is illegal. Use this tool responsibly.
"@
    
    return $result
}

# Define 200 hacking services (extended from 150)
$hackingServices = @(
    # Network Attacks (1-20)
    @{ID=1; Name="Network Reconnaissance"; Category="Network"; Target="Network Segment"; Duration=15},
    @{ID=2; Name="Port Storm Attack"; Category="Network"; Target="Firewall"; Duration=20},
    @{ID=3; Name="DNS Amplification"; Category="Network"; Target="DNS Server"; Duration=25},
    @{ID=4; Name="SYN Flood Attack"; Category="Network"; Target="Web Server"; Duration=18},
    @{ID=5; Name="ARP Poisoning"; Category="Network"; Target="Internal Network"; Duration=22},
    @{ID=6; Name="BGP Hijacking"; Category="Network"; Target="Internet Routing"; Duration=30},
    @{ID=7; Name="ICMP Redirect Attack"; Category="Network"; Target="Network Devices"; Duration=20},
    @{ID=8; Name="VLAN Hopping"; Category="Network"; Target="Switched Networks"; Duration=25},
    @{ID=9; Name="TCP RST Injection"; Category="Network"; Target="TCP Sessions"; Duration=18},
    @{ID=10; Name="NTP Reflection"; Category="Network"; Target="Time Servers"; Duration=22},
    @{ID=11; Name="QUIC Protocol Exploit"; Category="Network"; Target="HTTP/3 Services"; Duration=25},
    @{ID=12; Name="SDN Controller Takeover"; Category="Network"; Target="Software Networks"; Duration=30},
    @{ID=13; Name="MPLS Header Poisoning"; Category="Network"; Target="Core Networks"; Duration=28},
    @{ID=14; Name="CDN Cache Poisoning"; Category="Network"; Target="Content Networks"; Duration=25},
    @{ID=15; Name="IoT Botnet Recruitment"; Category="Network"; Target="Smart Devices"; Duration=35},
    @{ID=16; Name="Tor Exit Node Eavesdropping"; Category="Network"; Target="Anonymous Traffic"; Duration=30},
    @{ID=17; Name="VoIP Call Interception"; Category="Network"; Target="Phone Systems"; Duration=25},
    @{ID=18; Name="RDP Session Hijacking"; Category="Network"; Target="Remote Desktops"; Duration=28},
    @{ID=19; Name="IPMI Exploitation"; Category="Network"; Target="Server Management"; Duration=30},
    @{ID=20; Name="Industrial Protocol Attack"; Category="Network"; Target="SCADA Systems"; Duration=40},
    
    # System Exploits (21-40)
    @{ID=21; Name="Kernel Privilege Escalation"; Category="System"; Target="Linux Server"; Duration=30},
    @{ID=22; Name="Windows EternalBlue Exploit"; Category="System"; Target="Windows Server"; Duration=35},
    @{ID=23; Name="Sudo Vulnerability Exploit"; Category="System"; Target="Unix Systems"; Duration=25},
    @{ID=24; Name="Dirty Pipe Exploitation"; Category="System"; Target="Linux Kernel"; Duration=28},
    @{ID=25; Name="ZeroLogon Attack"; Category="System"; Target="Domain Controller"; Duration=40},
    @{ID=26; Name="SAM Database Extraction"; Category="System"; Target="Windows Registry"; Duration=30},
    @{ID=27; Name="LSASS Memory Dumping"; Category="System"; Target="Windows Security"; Duration=25},
    @{ID=28; Name="UEFI Firmware Flashing"; Category="System"; Target="System BIOS"; Duration=40},
    @{ID=29; Name="Hypervisor Escape"; Category="System"; Target="Virtual Machines"; Duration=35},
    @{ID=30; Name="Secure Boot Bypass"; Category="System"; Target="Boot Process"; Duration=30},
    @{ID=31; Name="TPM Chip Exploitation"; Category="System"; Target="Hardware Security"; Duration=40},
    @{ID=32; Name="ACPI Firmware Attack"; Category="System"; Target="Power Management"; Duration=35},
    @{ID=33; Name="SMM Rootkit Installation"; Category="System"; Target="System Management"; Duration=40},
    @{ID=34; Name="Intel ME Compromise"; Category="System"; Target="Management Engine"; Duration=45},
    @{ID=35; Name="AMD PSP Takeover"; Category="System"; Target="Platform Security"; Duration=45},
    @{ID=36; Name="Container Breakout"; Category="System"; Target="Docker Containers"; Duration=30},
    @{ID=37; Name="Kubernetes Node Takeover"; Category="System"; Target="Cluster Nodes"; Duration=35},
    @{ID=38; Name="Windows COM Hijacking"; Category="System"; Target="Component Object Model"; Duration=30},
    @{ID=39; Name="Linux Capabilities Abuse"; Category="System"; Target="Privileged Processes"; Duration=25},
    @{ID=40; Name="Windows DLL Hijacking"; Category="System"; Target="Application Libraries"; Duration=28},
    
    # Web Hacking (41-60)
    @{ID=41; Name="SQL Injection"; Category="Web"; Target="Web Application"; Duration=20},
    @{ID=42; Name="XSS Worm Deployment"; Category="Web"; Target="Web Portal"; Duration=18},
    @{ID=43; Name="API Endpoint Fuzzing"; Category="Web"; Target="REST API"; Duration=22},
    @{ID=44; Name="JWT Token Cracking"; Category="Web"; Target="Authentication System"; Duration=25},
    @{ID=45; Name="OAuth Token Hijacking"; Category="Web"; Target="SSO Provider"; Duration=30},
    @{ID=46; Name="WebSocket Hijacking"; Category="Web"; Target="Real-time Apps"; Duration=25},
    @{ID=47; Name="GraphQL Injection"; Category="Web"; Target="API Endpoints"; Duration=22},
    @{ID=48; Name="SSRF Exploitation"; Category="Web"; Target="Internal Services"; Duration=28},
    @{ID=49; Name="XXE Injection"; Category="Web"; Target="XML Parsers"; Duration=25},
    @{ID=50; Name="Web Cache Poisoning"; Category="Web"; Target="Caching Systems"; Duration=20},
    @{ID=51; Name="WebAssembly Exploit"; Category="Web"; Target="Client Apps"; Duration=25},
    @{ID=52; Name="Progressive Web App Hijack"; Category="Web"; Target="PWA Services"; Duration=30},
    @{ID=53; Name="IndexedDB Manipulation"; Category="Web"; Target="Browser Storage"; Duration=25},
    @{ID=54; Name="CORS Misconfig Exploit"; Category="Web"; Target="Web Security"; Duration=22},
    @{ID=55; Name="HSTS Bypass Attack"; Category="Web"; Target="HTTPS Enforcement"; Duration=28},
    @{ID=56; Name="DOM Clobbering Attack"; Category="Web"; Target="Browser DOM"; Duration=25},
    @{ID=57; Name="WebRTC IP Leak Exploit"; Category="Web"; Target="Real-time Comms"; Duration=22},
    @{ID=58; Name="CSRF Token Bypass"; Category="Web"; Target="Web Forms"; Duration=20},
    @{ID=59; Name="HTTP Request Smuggling"; Category="Web"; Target="Web Servers"; Duration=30},
    @{ID=60; Name="WebDAV Exploitation"; Category="Web"; Target="File Servers"; Duration=25},
    
    # Credential Attacks (61-80)
    @{ID=61; Name="Password Spray Attack"; Category="Credentials"; Target="User Accounts"; Duration=20},
    @{ID=62; Name="Kerberoasting"; Category="Credentials"; Target="Active Directory"; Duration=35},
    @{ID=63; Name="Pass-the-Hash Attack"; Category="Credentials"; Target="Domain Admin"; Duration=25},
    @{ID=64; Name="Golden Ticket Attack"; Category="Credentials"; Target="Kerberos"; Duration=40},
    @{ID=65; Name="Credential Stuffing"; Category="Credentials"; Target="Login Portal"; Duration=15},
    @{ID=66; Name="LLMNR/NBT-NS Poisoning"; Category="Credentials"; Target="Network Protocols"; Duration=25},
    @{ID=67; Name="DPAPI Master Key Extraction"; Category="Credentials"; Target="Windows Vault"; Duration=30},
    @{ID=68; Name="Password Policy Bypass"; Category="Credentials"; Target="Security Policies"; Duration=20},
    @{ID=69; Name="Biometric Spoofing"; Category="Credentials"; Target="Auth Systems"; Duration=35},
    @{ID=70; Name="MFA Fatigue Attack"; Category="Credentials"; Target="2FA Systems"; Duration=25},
    @{ID=71; Name="Password Manager Exploit"; Category="Credentials"; Target="Vault Systems"; Duration=30},
    @{ID=72; Name="Hardware Token Cloning"; Category="Credentials"; Target="Physical 2FA"; Duration=35},
    @{ID=73; Name="Password Reset Exploit"; Category="Credentials"; Target="Recovery Systems"; Duration=25},
    @{ID=74; Name="Session Cookie Theft"; Category="Credentials"; Target="Browser Sessions"; Duration=20},
    @{ID=75; Name="OAuth Token Redirect"; Category="Credentials"; Target="Social Logins"; Duration=25},
    @{ID=76; Name="Windows Hello Bypass"; Category="Credentials"; Target="Biometric Auth"; Duration=30},
    @{ID=77; Name="SAML Token Forging"; Category="Credentials"; Target="Enterprise SSO"; Duration=35},
    @{ID=78; Name="Windows Credential Guard Bypass"; Category="Credentials"; Target="Credential Protection"; Duration=40},
    @{ID=79; Name="Linux PAM Module Exploit"; Category="Credentials"; Target="Pluggable Auth"; Duration=30},
    @{ID=80; Name="Windows LSA Protection Bypass"; Category="Credentials"; Target="Local Security"; Duration=35},
    
    # Wireless Attacks (81-100)
    @{ID=81; Name="WiFi Pineapple Attack"; Category="Wireless"; Target="Corporate Wifi"; Duration=25},
    @{ID=82; Name="WPA3 Handshake Capture"; Category="Wireless"; Target="Secure Wifi"; Duration=30},
    @{ID=83; Name="Evil Twin Deployment"; Category="Wireless"; Target="Public Hotspot"; Duration=20},
    @{ID=84; Name="Bluetooth Snooping"; Category="Wireless"; Target="Mobile Devices"; Duration=18},
    @{ID=85; Name="NFC Data Theft"; Category="Wireless"; Target="Access Cards"; Duration=15},
    @{ID=86; Name="RFID Cloning"; Category="Wireless"; Target="Security Badges"; Duration=20},
    @{ID=87; Name="Zigbee Exploitation"; Category="Wireless"; Target="IoT Devices"; Duration=25},
    @{ID=88; Name="GSM Interception"; Category="Wireless"; Target="Mobile Networks"; Duration=30},
    @{ID=89; Name="WiFi Deauthentication"; Category="Wireless"; Target="Network Clients"; Duration=18},
    @{ID=90; Name="LTE IMSI Catcher"; Category="Wireless"; Target="Cellular Devices"; Duration=35},
    @{ID=91; Name="Satellite Comms Exploit"; Category="Wireless"; Target="Satellite Networks"; Duration=40},
    @{ID=92; Name="LoRaWAN Eavesdropping"; Category="Wireless"; Target="IoT Networks"; Duration=30},
    @{ID=93; Name="Z-Wave Protocol Attack"; Category="Wireless"; Target="Home Automation"; Duration=25},
    @{ID=94; Name="WiFi 6E Vulnerability"; Category="Wireless"; Target="NextGen Networks"; Duration=35},
    @{ID=95; Name="5G Network Slicing Exploit"; Category="Wireless"; Target="Mobile Operators"; Duration=40},
    @{ID=96; Name="Bluetooth Key Injection"; Category="Wireless"; Target="BLE Devices"; Duration=30},
    @{ID=97; Name="Wireless HID Spoofing"; Category="Wireless"; Target="Input Devices"; Duration=25},
    @{ID=98; Name="RF Jamming Attack"; Category="Wireless"; Target="Wireless Signals"; Duration=20},
    @{ID=99; Name="Wireless Keyboard Sniffing"; Category="Wireless"; Target="Keyboard Comms"; Duration=25},
    @{ID=100; Name="NFC Relay Attack"; Category="Wireless"; Target="Contactless Payments"; Duration=30},
    
    # Malware & RATs (101-120)
    @{ID=101; Name="Trojan Dropper Deployment"; Category="Malware"; Target="Endpoints"; Duration=30},
    @{ID=102; Name="RAT Configuration"; Category="Malware"; Target="Workstations"; Duration=25},
    @{ID=103; Name="Fileless Malware Injection"; Category="Malware"; Target="Memory"; Duration=35},
    @{ID=104; Name="Macro Virus Deployment"; Category="Malware"; Target="Office Docs"; Duration=20},
    @{ID=105; Name="Bootkit Installation"; Category="Malware"; Target="System BIOS"; Duration=40},
    @{ID=106; Name="Cryptominer Deployment"; Category="Malware"; Target="Computing Resources"; Duration=30},
    @{ID=107; Name="Ransomware Propagation"; Category="Malware"; Target="Network Shares"; Duration=35},
    @{ID=108; Name="USB Drop Attack"; Category="Malware"; Target="Physical Access"; Duration=25},
    @{ID=109; Name="Document Exploit Crafting"; Category="Malware"; Target="Office Software"; Duration=30},
    @{ID=110; Name="Firmware Backdooring"; Category="Malware"; Target="Hardware Devices"; Duration=40},
    @{ID=111; Name="AI-Powered Malware"; Category="Malware"; Target="Security Systems"; Duration=45},
    @{ID=112; Name="Supply Chain Poisoning"; Category="Malware"; Target="Software Updates"; Duration=40},
    @{ID=113; Name="Fake Antivirus Deployment"; Category="Malware"; Target="Security Software"; Duration=30},
    @{ID=114; Name="Browser Extension Exploit"; Category="Malware"; Target="Web Browsers"; Duration=25},
    @{ID=115; Name="Signed Malware Injection"; Category="Malware"; Target="Trusted Processes"; Duration=35},
    @{ID=116; Name="UEFI Rootkit Installation"; Category="Malware"; Target="System Firmware"; Duration=45},
    @{ID=117; Name="Linux Kernel Module Rootkit"; Category="Malware"; Target="Kernel Space"; Duration=40},
    @{ID=118; Name="Windows Driver Exploit"; Category="Malware"; Target="Kernel Drivers"; Duration=35},
    @{ID=119; Name="MacOS Gatekeeper Bypass"; Category="Malware"; Target="Apple Security"; Duration=30},
    @{ID=120; Name="Android Stagefright Exploit"; Category="Malware"; Target="Mobile Devices"; Duration=35},
    
    # Cloud & Container (121-140)
    @{ID=121; Name="AWS S3 Bucket Enumeration"; Category="Cloud"; Target="Cloud Storage"; Duration=18},
    @{ID=122; Name="Kubernetes Privilege Escalation"; Category="Cloud"; Target="Container Cluster"; Duration=30},
    @{ID=123; Name="Azure AD Compromise"; Category="Cloud"; Target="Cloud Directory"; Duration=35},
    @{ID=124; Name="Docker Escape Exploit"; Category="Cloud"; Target="Container"; Duration=25},
    @{ID=125; Name="Cloud Metadata API Exploit"; Category="Cloud"; Target="Cloud Instance"; Duration=20},
    @{ID=126; Name="Serverless Function Abuse"; Category="Cloud"; Target="Lambda/Functions"; Duration=25},
    @{ID=127; Name="Cloud Credential Harvesting"; Category="Cloud"; Target="IAM Roles"; Duration=30},
    @{ID=128; Name="Container Registry Poisoning"; Category="Cloud"; Target="Docker Registry"; Duration=25},
    @{ID=129; Name="Cloud Log Manipulation"; Category="Cloud"; Target="Monitoring Systems"; Duration=20},
    @{ID=130; Name="Cloud Resource Exhaustion"; Category="Cloud"; Target="Cloud Budget"; Duration=35},
    @{ID=131; Name="Cloud Cryptojacking"; Category="Cloud"; Target="Compute Resources"; Duration=30},
    @{ID=132; Name="SaaS Configuration Abuse"; Category="Cloud"; Target="Software Services"; Duration=25},
    @{ID=133; Name="Cloud Database Exfiltration"; Category="Cloud"; Target="DB Services"; Duration=35},
    @{ID=134; Name="Container Sidecar Attack"; Category="Cloud"; Target="Microservices"; Duration=30},
    @{ID=135; Name="Cloud API Key Theft"; Category="Cloud"; Target="Service Accounts"; Duration=25},
    @{ID=136; Name="Cloud WAF Bypass"; Category="Cloud"; Target="Web Application Firewall"; Duration=30},
    @{ID=137; Name="Cloud Bastion Host Compromise"; Category="Cloud"; Target="Jump Servers"; Duration=35},
    @{ID=138; Name="Cloud CSPM Policy Bypass"; Category="Cloud"; Target="Security Policies"; Duration=25},
    @{ID=139; Name="Cloud CI/CD Pipeline Poisoning"; Category="Cloud"; Target="Deployment Systems"; Duration=40},
    @{ID=140; Name="Cloud Secrets Manager Exploit"; Category="Cloud"; Target="Sensitive Configs"; Duration=35},
    
    # Social Engineering (141-160)
    @{ID=141; Name="Phishing Kit Deployment"; Category="Social"; Target="Employee Emails"; Duration=20},
    @{ID=142; Name="CEO Fraud Simulation"; Category="Social"; Target="Executives"; Duration=25},
    @{ID=143; Name="Vishing Infrastructure"; Category="Social"; Target="Call Centers"; Duration=18},
    @{ID=144; Name="QR Code Phishing"; Category="Social"; Target="Mobile Users"; Duration=15},
    @{ID=145; Name="Physical Badge Cloning"; Category="Social"; Target="Access Control"; Duration=30},
    @{ID=146; Name="Watering Hole Attack"; Category="Social"; Target="Trusted Websites"; Duration=25},
    @{ID=147; Name="Tailgating Simulation"; Category="Social"; Target="Physical Security"; Duration=20},
    @{ID=148; Name="Impersonation Attack"; Category="Social"; Target="Help Desks"; Duration=25},
    @{ID=149; Name="USB Drop Campaign"; Category="Social"; Target="Employee Curiosity"; Duration=20},
    @{ID=150; Name="Fake Update Deployment"; Category="Social"; Target="Software Updates"; Duration=30},
    @{ID=151; Name="Deepfake Voice Attack"; Category="Social"; Target="Voice Auth"; Duration=35},
    @{ID=152; Name="AI Chatbot Manipulation"; Category="Social"; Target="Support Systems"; Duration=25},
    @{ID=153; Name="Social Media Impersonation"; Category="Social"; Target="Online Presence"; Duration=20},
    @{ID=154; Name="Fake Job Offer Scam"; Category="Social"; Target="Job Seekers"; Duration=25},
    @{ID=155; Name="Tech Support Scam"; Category="Social"; Target="General Public"; Duration=20},
    @{ID=156; Name="Fake Emergency Scenario"; Category="Social"; Target="Human Psychology"; Duration=25},
    @{ID=157; Name="Malicious QR Code Attack"; Category="Social"; Target="Mobile Scanning"; Duration=20},
    @{ID=158; Name="Fake Social Media Profile"; Category="Social"; Target="Online Trust"; Duration=25},
    @{ID=159; Name="Physical Security Bypass"; Category="Social"; Target="Facility Access"; Duration=30},
    @{ID=160; Name="In-Person Social Engineering"; Category="Social"; Target="Human Interaction"; Duration=35},
    
    # Cryptography (161-180)
    @{ID=161; Name="Ransomware Deployment"; Category="Crypto"; Target="File Servers"; Duration=40},
    @{ID=162; Name="SSL Stripping Attack"; Category="Crypto"; Target="HTTPS Traffic"; Duration=25},
    @{ID=163; Name="Cryptojacking Operation"; Category="Crypto"; Target="Cloud Resources"; Duration=35},
    @{ID=164; Name="SHA1 Collision Attack"; Category="Crypto"; Target="Digital Certificates"; Duration=30},
    @{ID=165; Name="Cryptocurrency Wallet Theft"; Category="Crypto"; Target="Blockchain Wallets"; Duration=40},
    @{ID=166; Name="TLS Downgrade Attack"; Category="Crypto"; Target="Secure Channels"; Duration=25},
    @{ID=167; Name="Certificate Authority Compromise"; Category="Crypto"; Target="Trust Chains"; Duration=35},
    @{ID=168; Name="Quantum-Resistant Cracking"; Category="Crypto"; Target="Future Cryptography"; Duration=40},
    @{ID=169; Name="Cryptographic Backdoor"; Category="Crypto"; Target="Encryption Algorithms"; Duration=35},
    @{ID=170; Name="Ransomware Negotiation"; Category="Crypto"; Target="Victim Communication"; Duration=30},
    @{ID=171; Name="Blockchain Consensus Attack"; Category="Crypto"; Target="Distributed Ledgers"; Duration=45},
    @{ID=172; Name="Smart Contract Exploit"; Category="Crypto"; Target="DeFi Platforms"; Duration=40},
    @{ID=173; Name="Crypto Mixer Analysis"; Category="Crypto"; Target="Anonymity Tools"; Duration=35},
    @{ID=174; Name="Zero-Knowledge Proof Break"; Category="Crypto"; Target="Privacy Systems"; Duration=40},
    @{ID=175; Name="Post-Quantum Crypto Attack"; Category="Crypto"; Target="Future Systems"; Duration=45},
    @{ID=176; Name="Homomorphic Encryption Break"; Category="Crypto"; Target="Encrypted Processing"; Duration=50},
    @{ID=177; Name="Blockchain Front-Running"; Category="Crypto"; Target="Transaction Ordering"; Duration=40},
    @{ID=178; Name="Cryptocurrency Dusting"; Category="Crypto"; Target="Wallet Privacy"; Duration=35},
    @{ID=179; Name="MPC Protocol Exploit"; Category="Crypto"; Target="Multi-Party Computation"; Duration=45},
    @{ID=180; Name="Threshold Signature Attack"; Category="Crypto"; Target="Distributed Signing"; Duration=40},
    
    # Forensics & Anti-Forensics (181-200)
    @{ID=181; Name="Log Wiping Utility"; Category="Forensics"; Target="System Logs"; Duration=20},
    @{ID=182; Name="Metadata Removal Tool"; Category="Forensics"; Target="Documents"; Duration=18},
    @{ID=183; Name="File Carving Recovery"; Category="Forensics"; Target="Deleted Files"; Duration=25},
    @{ID=184; Name="Memory Dump Analysis"; Category="Forensics"; Target="RAM Capture"; Duration=30},
    @{ID=185; Name="Steganography Detection"; Category="Forensics"; Target="Media Files"; Duration=22},
    @{ID=186; Name="Timestomp Utility"; Category="Forensics"; Target="File Metadata"; Duration=20},
    @{ID=187; Name="Data Sanitization Tool"; Category="Forensics"; Target="Sensitive Data"; Duration=25},
    @{ID=188; Name="Network Traffic Obfuscation"; Category="Forensics"; Target="Packet Captures"; Duration=30},
    @{ID=189; Name="Anti-Forensics Toolkit"; Category="Forensics"; Target="Incident Response"; Duration=35},
    @{ID=190; Name="Disk Encryption Bypass"; Category="Forensics"; Target="Encrypted Drives"; Duration=40},
    @{ID=191; Name="RAM Scraping Prevention"; Category="Forensics"; Target="Memory Analysis"; Duration=30},
    @{ID=192; Name="File System Artifact Wiping"; Category="Forensics"; Target="Forensic Traces"; Duration=25},
    @{ID=193; Name="Browser History Manipulation"; Category="Forensics"; Target="User Activity"; Duration=20},
    @{ID=194; Name="Registry Key Obfuscation"; Category="Forensics"; Target="System Traces"; Duration=25},
    @{ID=195; Name="Cloud Artifact Removal"; Category="Forensics"; Target="Cloud Traces"; Duration=30},
    @{ID=196; Name="Memory Analysis Evasion"; Category="Forensics"; Target="Volatility"; Duration=35},
    @{ID=197; Name="NTFS Alternate Data Streams"; Category="Forensics"; Target="File System"; Duration=25},
    @{ID=198; Name="EFI Variable Manipulation"; Category="Forensics"; Target="Boot Process"; Duration=30},
    @{ID=199; Name="BIOS Log Wiping"; Category="Forensics"; Target="Firmware Logs"; Duration=35},
    @{ID=200; Name="TPM Log Tampering"; Category="Forensics"; Target="Trusted Platform Module"; Duration=40}
)

# Create Hack Data folder on desktop
$desktopPath = [Environment]::GetFolderPath("Desktop")
$hackDataPath = Join-Path -Path $desktopPath -ChildPath "Hack Data"

if (-not (Test-Path -Path $hackDataPath)) {
    New-Item -ItemType Directory -Path $hackDataPath | Out-Null
    Write-Host "Created Hack Data directory at: $hackDataPath" -ForegroundColor Green
}

# Custom attack function with duration control
function Invoke-CustomAttack {
    param (
        [string]$Target
    )
    
    $attackName = Read-Host "Enter custom attack name"
    
    # Get custom duration with validation
    $duration = 0
    while ($duration -lt 5 -or $duration -gt 300) {
        $input = Read-Host "Enter attack duration in seconds (5-300)"
        if ([int]::TryParse($input, [ref]$duration)) {
            if ($duration -lt 5 -or $duration -gt 300) {
                Write-Host "Duration must be between 5 and 300 seconds" -ForegroundColor Red
            }
        }
        else {
            Write-Host "Please enter a valid number" -ForegroundColor Red
        }
    }
    
    # Run hacking simulation
    Show-HackingEffect -Duration $duration -Target $Target -AttackType "Custom: $attackName"
    
    # Generate results
    $result = Get-FakeHackingResults -ServiceName $attackName -Target $Target -Duration $duration
    
    # Save to file in Hack Data folder
    $filename = "Hack_${attackName}_$(Get-Date -Format 'yyyyMMddHHmmss').txt"
    $filePath = Join-Path -Path $hackDataPath -ChildPath $filename
    $result | Out-File $filePath
    
    # Add to attack history
    $global:attackHistory += [PSCustomObject]@{
        Time = Get-Date
        Attack = "Custom: $attackName"
        Target = $Target
        Duration = "$duration seconds"
        File = $filePath
    }
    
    Write-Host "`n=== CUSTOM ATTACK RESULTS ===" -ForegroundColor Green
    $result -split "`n" | Select-Object -First 15 | ForEach-Object {
        Write-Host $_ -ForegroundColor Cyan
    }
    Write-Host "`nFull results saved to: $filePath" -ForegroundColor Yellow
}

# Quick Attack function
function Invoke-QuickAttack {
    param (
        [string]$Target
    )
    
    $service = $hackingServices | Get-Random
    $duration = Get-Random -Minimum 5 -Maximum 16  # 5-15 seconds
    
    # Run hacking simulation
    Show-HackingEffect -Duration $duration -Target $Target -AttackType "Quick: $($service.Name)"
    
    # Generate results
    $result = Get-FakeHackingResults -ServiceName $service.Name -Target $Target -Duration $duration
    
    # Save to file in Hack Data folder
    $filename = "Hack_$($service.Name.Replace(' ','_'))_$(Get-Date -Format 'yyyyMMddHHmmss').txt"
    $filePath = Join-Path -Path $hackDataPath -ChildPath $filename
    $result | Out-File $filePath
    
    # Add to attack history
    $global:attackHistory += [PSCustomObject]@{
        Time = Get-Date
        Attack = "Quick: $($service.Name)"
        Target = $Target
        Duration = "$duration seconds"
        File = $filePath
    }
    
    Write-Host "`n=== QUICK ATTACK RESULTS ===" -ForegroundColor Green
    $result -split "`n" | Select-Object -First 15 | ForEach-Object {
        Write-Host $_ -ForegroundColor Cyan
    }
    Write-Host "`nFull results saved to: $filePath" -ForegroundColor Yellow
}

# Attack history function
function Show-AttackHistory {
    Clear-Host
    Write-Host "`n=== ATTACK HISTORY ===" -ForegroundColor Cyan
    Write-Host "Date".PadRight(20) + "Attack".PadRight(40) + "Target".PadRight(20) + "Duration".PadRight(12) + "File" -ForegroundColor Yellow
    
    if ($global:attackHistory.Count -eq 0) {
        Write-Host "`nNo attacks recorded yet" -ForegroundColor Magenta
        return
    }
    
    $global:attackHistory | Sort-Object Time -Descending | ForEach-Object {
        $time = $_.Time.ToString("yyyy-MM-dd HH:mm")
        Write-Host $time.PadRight(20) + $_.Attack.PadRight(40) + $_.Target.PadRight(20) + $_.Duration.PadRight(12) + $_.File -ForegroundColor Cyan
    }
}

# Revamped UI with pagination
function Show-MainMenu {
    param (
        [int]$Page = 1
    )
    
    $servicesPerPage = 15
    $totalPages = [math]::Ceiling($hackingServices.Count / $servicesPerPage)
    $startIndex = ($Page - 1) * $servicesPerPage
    $endIndex = [math]::Min($startIndex + $servicesPerPage - 1, $hackingServices.Count - 1)
    
    Clear-Host
    Write-Host ""
    Write-Host "            " -ForegroundColor Cyan
    Write-Host "       " -ForegroundColor Cyan
    Write-Host "                    " -ForegroundColor Cyan
    Write-Host "                  " -ForegroundColor Cyan
    Write-Host "                       " -ForegroundColor Cyan
    Write-Host "                            " -ForegroundColor Cyan
    Write-Host ""
    Write-Host "" -ForegroundColor Red
    Write-Host "                  ULTIMATE HACKING TOOLKIT v15.0              " -ForegroundColor Red
    Write-Host "" -ForegroundColor Red
    Write-Host " Current Target: $($globalTarget.PadRight(42)) " -ForegroundColor Yellow
    Write-Host "" -ForegroundColor DarkGray
    
    # Display services for current page
    for ($i = $startIndex; $i -le $endIndex; $i++) {
        $service = $hackingServices[$i]
        $display = "$($service.ID.ToString().PadLeft(3)) - $($service.Name)"
        Write-Host " $($display.PadRight(58)) " -ForegroundColor Cyan
    }
    
    # Fill remaining lines if needed
    $linesToFill = $servicesPerPage - ($endIndex - $startIndex + 1)
    for ($i = 0; $i -lt $linesToFill; $i++) {
        Write-Host "                                                            "
    }
    
    Write-Host "" -ForegroundColor DarkGray
    Write-Host " Page: $Page/$totalPages".PadRight(58) + " " -ForegroundColor Magenta
    Write-Host "" -ForegroundColor DarkGray
    Write-Host " Navigation:                                                 " -ForegroundColor Green
    Write-Host "   N - Next Page          P - Previous Page                  " -ForegroundColor Green
    Write-Host "   T - Change Target      C - Custom Attack                  " -ForegroundColor Green
    Write-Host "   Q - Quick Attack       H - Attack History                 " -ForegroundColor Green
    Write-Host "   R - Random Attack      S - Search Attacks                 " -ForegroundColor Green
    Write-Host "   0 - Exit Toolkit                                          " -ForegroundColor Yellow
    Write-Host "" -ForegroundColor Red
}

# Search function
function Search-Attacks {
    $searchTerm = Read-Host "Enter search term"
    $results = $hackingServices | Where-Object { $_.Name -match $searchTerm }
    
    if ($results) {
        Clear-Host
        Write-Host "`nSearch Results for '$searchTerm':`n" -ForegroundColor Yellow
        $results | ForEach-Object {
            Write-Host "$($_.ID.ToString().PadLeft(3)) - $($_.Name)" -ForegroundColor Cyan
        }
        Write-Host "`nPress any key to continue..." -ForegroundColor Gray
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
        return $true
    }
    else {
        Write-Host "No attacks found matching '$searchTerm'" -ForegroundColor Red
        Start-Sleep -Seconds 2
        return $false
    }
}

# Main execution
$globalTarget = "CORPORATE-NETWORK"
$currentPage = 1
$totalPages = [math]::Ceiling($hackingServices.Count / 15)
$global:attackHistory = @()
$enableSounds = $true

Write-Host "WARNING: This tool is for educational purposes only!" -ForegroundColor Red
Write-Host "Unauthorized hacking is illegal. Use at your own risk.`n" -ForegroundColor Yellow
Write-Host "Hack data will be saved to: $hackDataPath" -ForegroundColor Cyan
Write-Host "Initial target set to: $globalTarget" -ForegroundColor Cyan
Start-Sleep -Seconds 2

$choice = $null
do {
    Show-MainMenu -Page $currentPage
    $choice = Read-Host "`nSelect an option (1-200, N, P, T, C, Q, H, R, S, 0)"

    switch -Wildcard ($choice) {
        "N" { 
            if ($currentPage -lt $totalPages) {
                $currentPage++
            }
            continue  # Skip the pause at the end
        }
        "P" { 
            if ($currentPage -gt 1) {
                $currentPage--
            }
            continue  # Skip the pause at the end
        }
        "T" { 
            $globalTarget = Read-Host "Enter new target name"
            Write-Host "Target updated to: $globalTarget" -ForegroundColor Green
            Start-Sleep -Seconds 2
            continue  # Skip the pause at the end
        }
        "C" {
            Invoke-CustomAttack -Target $globalTarget
            Write-Host "`nPress any key to return to menu..." -ForegroundColor Gray
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            continue  # Skip the pause at the end
        }
        "Q" {
            Invoke-QuickAttack -Target $globalTarget
            Write-Host "`nPress any key to return to menu..." -ForegroundColor Gray
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            continue  # Skip the pause at the end
        }
        "H" {
            Show-AttackHistory
            Write-Host "`nPress any key to return to menu..." -ForegroundColor Gray
            $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
            continue  # Skip the pause at the end
        }
        "R" {
            $randomService = $hackingServices | Get-Random
            $choice = $randomService.ID
            # Fall through to numeric processing
        }
        "S" {
            $searchPerformed = Search-Attacks
            if (-not $searchPerformed) {
                continue
            }
            continue  # Skip the pause at the end
        }
        {$_ -match "^\d+$" -and [int]$_ -ge 1 -and [int]$_ -le 200} {
            $service = $hackingServices | Where-Object { $_.ID -eq [int]$choice }
            if ($service) {
                # Run hacking simulation
                $duration = if ($service.Duration) { $service.Duration } else { Get-Random -Minimum 10 -Maximum 41 }
                Show-HackingEffect -Duration $duration -Target $globalTarget -AttackType $service.Name
                
                # Generate and display results
                $result = Get-FakeHackingResults -ServiceName $service.Name -Target $globalTarget -Duration $duration
                
                # Save to file in Hack Data folder
                $filename = "Hack_$($service.Name.Replace(' ','_'))_$(Get-Date -Format 'yyyyMMddHHmmss').txt"
                $filePath = Join-Path -Path $hackDataPath -ChildPath $filename
                $result | Out-File $filePath
                
                # Add to attack history
                $global:attackHistory += [PSCustomObject]@{
                    Time = Get-Date
                    Attack = $service.Name
                    Target = $globalTarget
                    Duration = "$duration seconds"
                    File = $filePath
                }
                
                Write-Host "`n=== HACKING RESULTS ===" -ForegroundColor Green
                $result -split "`n" | Select-Object -First 15 | ForEach-Object {
                    Write-Host $_ -ForegroundColor Cyan
                }
                Write-Host "`nFull results saved to: $filePath" -ForegroundColor Yellow
            }
        }
        "0" { Write-Host "Exiting..." -ForegroundColor Yellow }
        default { Write-Host "Invalid option!" -ForegroundColor Red }
    }
    
    if ($choice -ne '0') {
        Write-Host "`nPress any key to return to menu..." -ForegroundColor Gray
        $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    }
} while ($choice -ne '0')
