oh well hello thanks for downloading my HelpKitTool to set it up here are the steps
1. put the folder named In desktop Hack Data
2. Put the HelpKitTool_Clean.ps1 in Folder named public located ad  local c drive users and public
3. Click Ctrl+r
4.run this command cd C:\Users\Public and hit enter
5. then run this command 	Test-Path .\HelpKitTool_Clean.ps1 and if it says true the file is in the public folder and if then it isnt
6. then run this command .\HelpKitTool_Clean.ps1 andit should run

thanks for using my script have fun with it